import { useState } from "react"
import usefetchHooks from "./utils/usefetchHooks"
import PostsData from "./Components/PostsData";
import './App.css'

function App() {
  const postsData = usefetchHooks("https://jsonplaceholder.typicode.com/posts")
  // console.log(postsData);

  // const todosData = usefetchHooks("https://jsonplaceholder.typicode.com/todos")
  // console.log(todosData);
  return (
    
    <>
     <h1 className="heading">Fetch Data Using Custom Hooks</h1>
     {/* <PostsData/> */}
     <div className="postMap">
      {
        postsData.map((data,index ) => (
          <PostsData key={index} post = {data} />
        // <h1>{fetchData.id}</h1>  
        ))
      }
     </div>
    </>
  )
}

export default App


// Consolas, 'Courier New', monospace